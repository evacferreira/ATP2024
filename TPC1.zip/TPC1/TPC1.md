#Trabalho de Casa 1

Para iniciar o desenho da casa construiu-se um quadrado de 150 de lado.
Posteriomente, o desenho do telhado foi feito a partir de um triângulo isósceles. Para fazer as janelas e a porta da casa utilizaram-se 2 ciclos (de 4 repetições)  com as instruções:  move forward e turn right. 
O sol foi também desenhado através de 2 ciclos, um de 12 repetições para fazer os raios e outro de 360 para preencher o círculo.
Por último, a árvore foi construída por um retângulo no qual foi usado um ciclo de 2 repetições e também por um círculo em que, tal como no sol, usou-se um ciclo de 360 repetições.
