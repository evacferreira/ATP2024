#Trabalho de casa 4

Esta aplicaçaõ permite manipular e analisar dados de lista como calcular a soma e a média dos elementos dessa lista, identificar o maior e o menor número, verificar se esta está ordenada e até mesmo procurar um elemento específico na lista.

Ao iniciar o programa, é logo exposto ao utilizador o menu com asdiversas opções disponíveis. A primeira opção é Criar Lista, onde o tilizador pode gerar uma lista de números aleatórios entre 1 e 100. Para isso, o programa pergunta ao usuário quantos números deseja incluir na lista e usa a função randint para gerar esses x números aleatórios.

A segunda opção é Ler Lista, onde o programa pergunta ao jogador a quantidade de números que deseja na sua lista e, posteriormente, permite a inserção de cada número individualmente.

A terceira função é a Soma, que calcula a soma de todos os elementos presentes na lista,exibindo o resultado ao utilizador.

Assim como na Soma, na opção Média (quarta opção) é calculada a média dos elementos da lista. Para isso, o programa faz primeiro a soma de todos os elementos e, de seguida, divide pelo número total de elementos da lista. Esta só poderá ser calculada se a lista não estiver vazia.

A quinta função, Maior, procura o maior número na lista. Começa por assumir que o primeiro elemento é o maior e compara todos os outros elementos da lista para encontrar o maior.

A sexta opção, Menor, funciona de forma semelhante à função anterior, mas procura o menor número na lista. Também começa por admitir que o primeiro elemento da lista é o menor.

A sétima e a oitava opções verificam se a lista está ordenada. A opção Está Ordenada (Crescente) percorre a lista para determinar se todos os elementos estão em ordem crescente. O programa compara todos os pares de elementos e se encontar um em que o elemento seguinte é menor que o anterior, então a lista não está ordenada por ordem crescente. Por sua vez, a função Está Ordenada (Decrescente) verifica se os elementos estão em ordem decrescente, de modo semelhante ao anterior. Qunado o programa encontrar um par de elementos em que o primeiro é menor que o segundo, então a lista não está por ordem decrescente.

A nona função, Procurar um Elemento, permite que o usuário procure um número específico na lista. O programa informa o índice do elemento se ele estiver presente ou retorna -1 se o número não estiver na lista.

Por último, a opção Sair encerra o programa e exibe a lista final, que foi construída durante a execução.

